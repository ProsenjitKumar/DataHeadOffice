create function interval_time() returns trigger
    language plpgsql
as
$$
begin	
	if new.login_count > new.out_count then
		new.interval_time := login::time - logout::time from employee where pid = new.pid and today = current_date and TO_CHAR(current_timestamp, 'hh12:mi:ss AM') < '23:59:59 PM';
	end if;
	return new;
end;
$$;

alter function interval_time() owner to prosenjit;

