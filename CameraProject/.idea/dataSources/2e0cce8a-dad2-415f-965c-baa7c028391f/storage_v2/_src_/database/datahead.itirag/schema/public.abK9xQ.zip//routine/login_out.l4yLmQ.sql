create function login_out() returns trigger
    language plpgsql
as
$$
begin
	if new.lts_i <> old.lts_i then
		new.login := TO_CHAR(current_timestamp, 'hh12:mi:ss AM');
		new.today := current_date;
		insert into history values(old.pid, old.pname, new.desig, new.dept, old.lts_i, new.lts_O, old.lts_O, new.lts_O, old.p_status, 
			new.p_status, old.out_count, new.out_count, current_date, new.login_count, old.login_count,
			old.interval_time, new.interval_time, old.total_interval_time, new.total_interval_time);
		new.login_count := count(new_lts_i) from history where log_date = current_date and pid = new.pid;
	elsif new.lts_O <> old.lts_O then
		new.logout = TO_CHAR(current_timestamp, 'hh12:mi:ss AM');
		new.today := current_date;
		new.out_count := count(new_lts_O) from history where log_date = current_date and pid = new.pid;
	end if;
	return new;
end;
$$;

alter function login_out() owner to prosenjit;

