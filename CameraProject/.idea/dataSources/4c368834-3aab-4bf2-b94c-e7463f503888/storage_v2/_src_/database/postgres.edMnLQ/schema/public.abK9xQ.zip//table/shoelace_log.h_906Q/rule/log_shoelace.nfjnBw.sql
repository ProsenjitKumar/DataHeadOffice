CREATE RULE log_shoelace AS
    ON UPDATE TO public.shoelace_log
   WHERE (new.sl_avail <> old.sl_avail) DO  INSERT INTO shoelace_log (sl_name, sl_avail, log_who, log_when)
  VALUES (new.sl_name, new.sl_avail, CURRENT_USER, CURRENT_TIMESTAMP);

